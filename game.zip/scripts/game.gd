extends Node2D
## НЕОНОВЫЙ РЫВОК — автономный 2D platformer, Godot 4.7.2
## Original art assets. One scene, five levels, touch and keyboard input.

const SCREEN_W = 1280.0
const SCREEN_H = 720.0
const WORLD_W = 3750.0
const GRAVITY = 1720.0
const RUN_SPEED = 370.0
const DASH_SPEED = 680.0
const JUMP_SPEED = -760.0
const NAMES = ["ЗЕЛЁНЫЕ ХОЛМЫ", "ЛАЗУРНЫЙ БЕРЕГ", "ИЗУМРУДНЫЕ ДЖУНГЛИ", "НЕОНОВЫЙ ГОРОД", "НЕБЕСНЫЕ ОСТРОВА"]
const FILES = ["green_hills", "azure_coast", "emerald_jungle", "neon_city", "sky_islands"]

var backgrounds: Array[Texture2D] = []
var terrains: Array[Texture2D] = []
var hero: Dictionary = {}
var objects: Dictionary = {}
var sounds: Dictionary = {}
var sfx_player: AudioStreamPlayer
var state := "menu"  # menu, select, game, pause, complete, gameover
var level := 0
var unlocked := 1
var best_scores := [0, 0, 0, 0, 0]
var mute := false
var p := Vector2(160.0, 565.0) # feet coordinates
var v := Vector2.ZERO
var grounded := true
var facing := 1
var input_direction := 0
var keys_direction := 0
var dash_time := 0.0
var roll_time := 0.0
var i_frames := 0.0
var anim_time := 0.0
var game_time := 0.0
var rings_count := 0
var score := 0
var camera_x := 0.0
var respawn := Vector2(160, 565)
var platforms: Array[Rect2] = []
var rings: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var springs: Array[Vector2] = []
var checkpoints: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var touch_inputs: Dictionary = {} # id => side/-1/1/0; held touchscreen fingers
var top_touch_origin: Dictionary = {}
var last_tap_time := -10.0
var last_tap_side := 0
var tap_chain := 0
var jump_cooldown := 0.0
var level_time := 0.0
var button_rects: Dictionary = {}
var notification := ""
var notice_time := 0.0

func _ready() -> void:
    for n in FILES:
        backgrounds.append(load("res://assets/backgrounds/%s.jpg" % n))
        terrains.append(load("res://assets/tiles/%s.png" % n))
    for n in ["idle", "run_0", "run_1", "run_2", "run_3", "jump", "roll"]:
        hero[n] = load("res://assets/characters/%s.png" % n)
    for n in ["ring", "portal", "spring", "crab", "drone", "icon"]:
        objects[n] = load("res://assets/objects/%s.png" % n)
    for n in ["ring", "jump", "dash", "hurt", "win"]:
        sounds[n] = load("res://assets/sfx/%s.wav" % n)
    sfx_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    _load_save()
    _build_level(0)
    queue_redraw()

func _load_save() -> void:
    if not FileAccess.file_exists("user://neonrush.save"):
        return
    var f := FileAccess.open("user://neonrush.save", FileAccess.READ)
    if f == null:
        return
    var save: Variant = JSON.parse_string(f.get_as_text())
    if save is Dictionary:
        unlocked = clampi(int(save.get("unlocked", 1)), 1, 5)
        mute = bool(save.get("mute", false))
        var data: Variant = save.get("best", [])
        if data is Array and data.size() == 5:
            best_scores = data

func _save() -> void:
    var f := FileAccess.open("user://neonrush.save", FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify({"unlocked": unlocked, "best": best_scores, "mute": mute}))

func _sfx(which: String) -> void:
    if mute or not sounds.has(which):
        return
    sfx_player.stream = sounds[which]
    sfx_player.play()

func _build_level(index: int) -> void:
    level = clampi(index, 0, 4)
    platforms.clear()
    rings.clear()
    enemies.clear()
    springs.clear()
    checkpoints.clear()
    particles.clear()
    p = Vector2(155, 565)
    respawn = p
    v = Vector2.ZERO
    grounded = true
    facing = 1
    rings_count = 0
    score = 0
    game_time = 0.0
    dash_time = 0.0
    roll_time = 0.0
    camera_x = 0.0
    input_direction = 0
    touch_inputs.clear()
    top_touch_origin.clear()
    # Traversable ground, increasingly demanding gaps. Upper lanes for skilled jumps.
    var gaps: Array = [
        [960, 1760, 2720],
        [910, 1770, 2630],
        [870, 1640, 2580],
        [960, 1830, 2740],
        [870, 1630, 2510]
    ][level]
    var starts := [0, gaps[0] + 125, gaps[1] + 155, gaps[2] + 140]
    var stops := [gaps[0], gaps[1], gaps[2], WORLD_W]
    for j in range(4):
        platforms.append(Rect2(float(starts[j]), 565.0, float(stops[j] - starts[j]), 175.0))
    for j in range(8):
        var xx := 420.0 + 375.0 * float(j)
        var yy := 400.0 if j % 2 == 0 else 470.0
        if level >= 2 and j % 3 == 0:
            yy = 353.0
        platforms.append(Rect2(xx, yy, 180.0, 40.0))
        for r in range(4):
            _add_ring(Vector2(xx + 36 + r * 32, yy - 53))
    for j in range(70):
        var xx := 270.0 + float(j) * 47.0
        var ring_y := 493.0 - sin(float(j) * 0.45) * (42.0 + level * 5.0)
        if not _is_ground_at(xx):
            ring_y = 435.0
        _add_ring(Vector2(xx, ring_y))
    for j in range(7 + level * 2):
        var xx := 650.0 + 360.0 * float(j)
        if xx > 3480:
            continue
        var enemy_type := "drone" if j % 3 == 1 else "crab"
        var yy := 428.0 if enemy_type == "drone" else 535.0
        enemies.append({"p": Vector2(xx, yy), "start": xx, "phase": float(j), "type": enemy_type, "alive": true})
    springs = [Vector2(740.0, 545.0), Vector2(2445.0, 545.0)]
    checkpoints = [{"x": 1310.0, "used": false}, {"x": 2920.0, "used": false}]
    notification = "УРОВЕНЬ %d: %s" % [level + 1, NAMES[level]]
    notice_time = 2.4

func _add_ring(pos: Vector2) -> void:
    rings.append({"p": pos, "taken": false})

func _is_ground_at(x: float) -> bool:
    for r in platforms:
        if x >= r.position.x and x <= r.end.x and absf(r.position.y - 565.0) < 1:
            return true
    return false

func _physics_process(dt: float) -> void:
    if state != "game":
        queue_redraw()
        return
    game_time += dt
    anim_time += dt
    dash_time = maxf(0, dash_time - dt)
    roll_time = maxf(0, roll_time - dt)
    i_frames = maxf(0, i_frames - dt)
    jump_cooldown = maxf(0, jump_cooldown - dt)
    notice_time = maxf(0, notice_time - dt)
    var axis := input_direction
    if keys_direction != 0:
        axis = keys_direction
    var desired := float(axis) * (DASH_SPEED if dash_time > 0 else RUN_SPEED)
    if roll_time > 0:
        desired = float(facing) * maxf(430.0, absf(v.x) * 0.985)
    if axis != 0 and roll_time <= 0:
        facing = axis
    v.x = move_toward(v.x, desired, (1700.0 if grounded else 850.0) * dt)
    v.y = minf(1050.0, v.y + GRAVITY * dt)
    var previous_bottom := p.y
    p += v * dt
    p.x = clampf(p.x, 30, WORLD_W - 60.0)
    grounded = false
    if v.y >= 0:
        for plat in platforms:
            if p.x + 24.0 > plat.position.x and p.x - 24.0 < plat.end.x:
                if previous_bottom <= plat.position.y + 12.0 and p.y >= plat.position.y:
                    p.y = plat.position.y
                    v.y = 0
                    grounded = true
                    break
    if p.y > 820:
        _hurt(true)
        queue_redraw()
        return
    for k in range(rings.size()):
        if not rings[k]["taken"] and (p + Vector2(0, -52)).distance_to(rings[k]["p"]) < 65:
            rings[k]["taken"] = true
            rings_count += 1
            score += 100
            _emit_particles(rings[k]["p"], Color(1, .87, .3), 6)
            _sfx("ring")
    for sp in springs:
        if absf(p.x - sp.x) < 49 and absf(p.y - sp.y) < 44 and v.y >= 0:
            v.y = -1040
            grounded = false
            _emit_particles(sp + Vector2(0, -20), Color(.5, .95, 1), 12)
            _sfx("jump")
    for k in range(enemies.size()):
        if not enemies[k]["alive"]:
            continue
        var ep: Vector2 = enemies[k]["p"]
        if enemies[k]["type"] == "drone":
            ep.y += sin(game_time * 3.0 + float(enemies[k]["phase"])) * 21
        if absf(p.x - ep.x) < 53 and absf((p.y - 52) - ep.y) < 53:
            if roll_time > 0 or dash_time > 0 or (v.y > 180 and p.y < ep.y + 10):
                enemies[k]["alive"] = false
                score += 350
                v.y = -440
                _emit_particles(ep, Color(1, .35, .7), 16)
            elif i_frames <= 0:
                _hurt(false)
    for k in range(checkpoints.size()):
        if p.x >= float(checkpoints[k]["x"]) and not checkpoints[k]["used"]:
            checkpoints[k]["used"] = true
            respawn = Vector2(float(checkpoints[k]["x"]), 565.0)
            notification = "КОНТРОЛЬНАЯ ТОЧКА!"
            notice_time = 1.5
    if p.x > WORLD_W - 190.0:
        state = "complete"
        var total := score + rings_count * 40 + maxi(0, 6000 - int(game_time * 80))
        score = total
        best_scores[level] = maxi(int(best_scores[level]), total)
        unlocked = maxi(unlocked, mini(5, level + 2))
        _save()
        _sfx("win")
        touch_inputs.clear()
        input_direction = 0
    camera_x = clampf(p.x - 375.0, 0, WORLD_W - SCREEN_W)
    for k in range(particles.size() - 1, -1, -1):
        particles[k]["life"] = float(particles[k]["life"]) - dt
        var pp: Vector2 = particles[k]["p"]
        pp += particles[k]["velocity"] * dt
        particles[k]["p"] = pp
        if float(particles[k]["life"]) <= 0:
            particles.remove_at(k)
    if dash_time > 0 and randi() % 3 == 0:
        _emit_particles(p + Vector2(-facing * 45, -48), Color(.2, .9, 1), 2)
    queue_redraw()

func _emit_particles(at: Vector2, color: Color, how_many: int) -> void:
    for i in range(how_many):
        particles.append({"p": at, "velocity": Vector2(randf_range(-150, 150), randf_range(-220, 65)), "life": randf_range(.2, .65), "c": color})

func _hurt(fell: bool) -> void:
    if i_frames > 0 and not fell:
        return
    _sfx("hurt")
    if rings_count > 0 and not fell:
        _emit_particles(p + Vector2(0,-40), Color(1,.8,.25), mini(24, rings_count))
        rings_count = 0
        i_frames = 2.0
        v = Vector2(-facing * 270.0, -465.0)
    else:
        p = respawn
        v = Vector2.ZERO
        i_frames = 2.0
        rings_count = 0
        dash_time = 0
        roll_time = 0
        notification = "ПОПРОБУЙ ЕЩЁ!"
        notice_time = 1.3

func _jump() -> void:
    if state == "game" and (grounded or jump_cooldown > 0 and v.y > 0 and v.y < 100):
        v.y = JUMP_SPEED
        grounded = false
        jump_cooldown = 0
        _sfx("jump")
        _emit_particles(p, Color(.8,1,1), 9)

func _dash(side: int) -> void:
    if state != "game":
        return
    facing = side
    dash_time = .85
    roll_time = 0
    v.x = DASH_SPEED * float(side)
    _sfx("dash")
    _emit_particles(p + Vector2(0,-47), Color(.35,1,.95), 20)

func _roll(side: int) -> void:
    if state != "game":
        return
    facing = side
    roll_time = 2.3
    dash_time = .7
    v.x = DASH_SPEED * float(side)
    _sfx("dash")
    _emit_particles(p + Vector2(0,-42), Color(.8,.4,1), 16)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var ep: Vector2 = event.position
        if event.pressed:
            _touch_start(event.index, ep)
        else:
            _touch_end(event.index)
    elif event is InputEventScreenDrag:
        if top_touch_origin.has(event.index):
            var start_y: float = float(top_touch_origin[event.index])
            if start_y - event.position.y > 70:
                _jump()
                top_touch_origin.erase(event.index)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _touch_start(9999, event.position)
        else:
            _touch_end(9999)
    elif event is InputEventKey:
        if event.keycode in [KEY_RIGHT, KEY_D]:
            if event.pressed:
                keys_direction = 1
            elif keys_direction == 1:
                keys_direction = 0
        elif event.keycode in [KEY_LEFT, KEY_A]:
            if event.pressed:
                keys_direction = -1
            elif keys_direction == -1:
                keys_direction = 0
        elif event.pressed and not event.echo:
            if event.keycode in [KEY_SPACE, KEY_UP, KEY_W]:
                _jump()
            elif event.keycode in [KEY_SHIFT, KEY_X]:
                _dash(facing)
            elif event.keycode in [KEY_CTRL, KEY_C]:
                _roll(facing)
            elif event.keycode == KEY_ESCAPE:
                if state == "game":
                    state = "pause"
                elif state == "pause":
                    state = "game"
                else:
                    state = "menu"
                queue_redraw()

func _touch_start(id: int, pos: Vector2) -> void:
    if state != "game":
        _menu_tap(pos)
        return
    if pos.x > 1180 and pos.y < 103:
        state = "pause"
        queue_redraw()
        return
    if pos.y < 190:
        touch_inputs[id] = 0
        top_touch_origin[id] = pos.y
        _jump()
        return
    var side := -1 if pos.x < SCREEN_W / 2.0 else 1
    touch_inputs[id] = side
    _update_touch_axis()
    var now := float(Time.get_ticks_msec()) / 1000.0
    if side == last_tap_side and now - last_tap_time < .42:
        tap_chain += 1
    else:
        tap_chain = 1
    last_tap_time = now
    last_tap_side = side
    if tap_chain == 2:
        _dash(side)
    elif tap_chain >= 3:
        _roll(side)
        tap_chain = 0

func _touch_end(id: int) -> void:
    top_touch_origin.erase(id)
    touch_inputs.erase(id)
    _update_touch_axis()

func _update_touch_axis() -> void:
    input_direction = 0
    for side in touch_inputs.values():
        if int(side) != 0:
            input_direction = int(side)

func _menu_tap(pos: Vector2) -> void:
    for key in button_rects.keys():
        var r: Rect2 = button_rects[key]
        if r.has_point(pos):
            match key:
                "start":
                    _build_level(0)
                    state = "game"
                "levels":
                    state = "select"
                "settings":
                    mute = not mute
                    _save()
                "back":
                    state = "menu"
                "resume":
                    state = "game"
                "restart":
                    _build_level(level)
                    state = "game"
                "menu":
                    state = "menu"
                "next":
                    if level < 4:
                        _build_level(level + 1)
                        state = "game"
                    else:
                        state = "menu"
                _:
                    if str(key).begins_with("level_"):
                        var selected := int(str(key).trim_prefix("level_"))
                        if selected < unlocked:
                            _build_level(selected)
                            state = "game"
            queue_redraw()
            return

func _draw() -> void:
    button_rects.clear()
    _draw_background()
    if state in ["menu", "select"]:
        _draw_main_menu()
        return
    _draw_world()
    _draw_hud()
    if state == "pause":
        _draw_overlay("ПАУЗА", "Игра приостановлена", ["resume", "restart", "menu"])
    elif state == "complete":
        var subtitle := "Время: %s     Кольца: %d     Очки: %d" % [_clock(game_time), rings_count, score]
        _draw_overlay("УРОВЕНЬ ПРОЙДЕН!", subtitle, ["next", "restart", "menu"])

func _draw_background() -> void:
    var bg: Texture2D = backgrounds[level]
    # Parallax panoramic image: never stretch textures beyond authored 1920px.
    var slide := fposmod(camera_x * .13, 1920.0)
    for m in range(2):
        draw_texture_rect(bg, Rect2(-slide + m * 1920.0, 0, 1920, 720), false)
    draw_rect(Rect2(0, 510, 1280, 210), Color(.02,.07,.15,.08))

func _draw_world() -> void:
    draw_set_transform(Vector2(-camera_x, 0))
    var terrain: Texture2D = terrains[level]
    for plat in platforms:
        if plat.end.x < camera_x - 140 or plat.position.x > camera_x + SCREEN_W + 140:
            continue
        var tiles := int(ceilf(plat.size.x / 128.0))
        for k in range(tiles):
            var xx := plat.position.x + k * 128.0
            var tw := minf(128.0, plat.end.x - xx)
            draw_texture_rect_region(terrain, Rect2(xx, plat.position.y, tw, plat.size.y), Rect2(0, 0, tw, 128))
        draw_rect(Rect2(plat.position.x,plat.position.y+19,plat.size.x,6),Color(.07,.17,.27,.28))
    for ring in rings:
        if not ring["taken"]:
            var loc: Vector2 = ring["p"]
            if absf(loc.x - (camera_x + 640)) < 850:
                var s := 41 + sin(anim_time * 7 + loc.x * .05) * 3
                draw_texture_rect(objects["ring"], Rect2(loc.x-s/2,loc.y-s/2,s,s), false)
    for sp in springs:
        draw_texture_rect(objects["spring"], Rect2(sp.x-47,sp.y-34,94,58),false)
    for cp in checkpoints:
        var xx := float(cp["x"])
        draw_line(Vector2(xx,565),Vector2(xx,415),Color(.82,1,1),6)
        draw_colored_polygon(PackedVector2Array([Vector2(xx+4,414),Vector2(xx+70,440),Vector2(xx+4,465)]),Color(.2,1,.7) if cp["used"] else Color(1,.6,.18))
    for ent in enemies:
        if not ent["alive"]:
            continue
        var ep: Vector2 = ent["p"]
        var dy := sin(game_time * 3.0 + float(ent["phase"])) * 21 if ent["type"] == "drone" else 0.0
        var tex: Texture2D = objects[ent["type"]]
        draw_texture_rect(tex,Rect2(ep.x-46,ep.y-52+dy,92,82),false)
    var portal_x := WORLD_W - 130
    var pulse := sin(anim_time*4) * 6
    draw_texture_rect(objects["portal"],Rect2(portal_x-80-pulse/2,330-pulse/2,160+pulse,232+pulse),false)
    for pt in particles:
        var pv: Vector2 = pt["p"]
        draw_circle(pv, maxf(1.5, float(pt["life"])*12), pt["c"])
    if i_frames <= 0 or int(anim_time*14)%2 == 0:
        var sprite: Texture2D = hero["idle"]
        if roll_time > 0:
            sprite = hero["roll"]
        elif not grounded:
            sprite = hero["jump"]
        elif absf(v.x) > 50:
            sprite = hero["run_%d" % (int(anim_time*11) % 4)]
        var sprite_sz := Vector2(106,108) if roll_time > 0 else Vector2(123,135)
        draw_set_transform(Vector2(p.x-camera_x, p.y-18), 0, Vector2(float(facing),1))
        draw_texture_rect(sprite,Rect2(-sprite_sz.x*.5, -sprite_sz.y+20,sprite_sz.x,sprite_sz.y),false)
    draw_set_transform(Vector2.ZERO)

func _text(s: String, x: float, y: float, size: int = 26, color: Color = Color.WHITE, center: bool = false) -> void:
    var font := ThemeDB.fallback_font
    var text_width := font.get_string_size(s,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
    var xx := x-text_width/2 if center else x
    draw_string(font,Vector2(xx+2,y+3),s,HORIZONTAL_ALIGNMENT_LEFT,-1,size,Color(0,.07,.25,.72))
    draw_string(font,Vector2(xx,y),s,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func _pill(r: Rect2, fill: Color, border: Color = Color(1,1,1,.16), radius: int = 16) -> void:
    var box := StyleBoxFlat.new()
    box.bg_color = fill
    box.border_color = border
    box.set_border_width_all(2)
    box.set_corner_radius_all(radius)
    box.shadow_color = Color(0,.04,.24,.4)
    box.shadow_size = 7
    draw_style_box(box,r)

func _button(id: String, label: String, r: Rect2, primary: bool = false) -> void:
    button_rects[id] = r
    _pill(r, Color(.96,.62,.10,.98) if primary else Color(.02,.20,.46,.91),Color(1,.90,.55,.85) if primary else Color(.17,.76,1,.88),20)
    _text(label,r.position.x+r.size.x/2,r.position.y+r.size.y/2+10,26,Color(.11,.14,.31) if primary else Color.WHITE,true)

func _draw_main_menu() -> void:
    draw_rect(Rect2(0,0,1280,720),Color(.01,.04,.17,.34))
    if state == "menu":
        _pill(Rect2(54,47,590,162),Color(.015,.095,.30,.88),Color(.2,.78,1,.85),28)
        _text("НЕОНОВЫЙ",344,115,65,Color(.86,.98,1),true)
        _text("РЫВОК",344,184,70,Color(1,.80,.21),true)
        _button("start","▶  ИГРАТЬ",Rect2(100,278,390,71),true)
        _button("levels","◈  ВЫБОР УРОВНЯ",Rect2(100,370,390,67))
        _button("settings","♫  ЗВУК: %s" % ("ВЫКЛ" if mute else "ВКЛ"),Rect2(100,458,390,67))
        _pill(Rect2(680,428,538,210),Color(.03,.10,.30,.88),Color(.22,.78,1,.7),20)
        _text("УПРАВЛЕНИЕ",942,471,30,Color(.95,.87,.5),true)
        _text("← Удержание слева      Справа →",705,509,22)
        _text("×2 — рывок     ×3 — перекат",705,550,22)
        _text("Верх экрана — прыжок",705,591,22)
        draw_texture_rect(hero["idle"],Rect2(800,132,250,280),false)
    else:
        _pill(Rect2(110,40,1060,632),Color(.01,.09,.26,.89),Color(.18,.79,1,.8),28)
        _text("ВЫБЕРИ МИР",640,119,52,Color(1,.88,.45),true)
        for i in range(5):
            var x := 148.0 + float(i%3)*345.0
            var y := 156.0 + float(int(i/3))*206.0
            var r := Rect2(x,y,315,163)
            var unlocked_now := i < unlocked
            _pill(r,Color(.04,.23,.44,.92) if unlocked_now else Color(.13,.14,.2,.91),Color(.25,.84,.96,.8) if unlocked_now else Color(.5,.5,.55,.6))
            draw_texture_rect_region(backgrounds[i],Rect2(x+9,y+9,297,105),Rect2(255,100,1120,400))
            _text("%d  %s" % [i+1, NAMES[i]],x+12,y+143,19,Color.WHITE if unlocked_now else Color(.7,.7,.75))
            button_rects["level_%d" % i] = r
            if not unlocked_now:
                draw_rect(Rect2(x+9,y+9,297,105),Color(.02,.04,.12,.72))
                _text("🔒",x+156,y+80,40,Color.WHITE,true)
        _button("back","←  НАЗАД",Rect2(827,581,282,65))

func _draw_hud() -> void:
    _pill(Rect2(18,16,395,88),Color(.01,.10,.27,.86),Color(.19,.75,.99,.5),22)
    draw_texture_rect(objects["ring"],Rect2(36,35,48,48),false)
    _text("%03d" % rings_count,86,76,35,Color(1,.9,.45))
    _text("⏱  %s" % _clock(game_time),201,73,28)
    _pill(Rect2(432,18,415,69),Color(.02,.09,.28,.83),Color(.25,.72,.97,.47),18)
    _text("%d / 5 — %s" % [level+1,NAMES[level]],640,62,25,Color.WHITE,true)
    _pill(Rect2(1172,15,90,83),Color(.02,.10,.35,.91),Color(.3,.8,1,.75),19)
    _text("Ⅱ",1218,72,43,Color.WHITE,true)
    if notice_time > 0:
        _pill(Rect2(312,129,650,69),Color(.02,.1,.34,.82),Color(1,.82,.22,.8),25)
        _text(notification,637,173,26,Color(1,.9,.50),true)
    if OS.has_feature("mobile"):
        _pill(Rect2(25,613,275,82),Color(.06,.15,.40,.35))
        _pill(Rect2(980,613,275,82),Color(.06,.15,.40,.35))
        _text("◀  ВЛЕВО",162,668,25,Color(1,1,1,.75),true)
        _text("ВПРАВО  ▶",1113,668,25,Color(1,1,1,.75),true)
        _text("ВЕРХ — ПРЫЖОК",655,682,20,Color.WHITE,true)

func _draw_overlay(header: String, subtitle: String, actions: Array) -> void:
    draw_rect(Rect2(0,0,1280,720),Color(0,.03,.14,.72))
    _pill(Rect2(293,134,694,469),Color(.02,.11,.31,.96),Color(.34,.83,1,.88),30)
    _text(header,640,225,48,Color(1,.86,.35),true)
    _text(subtitle,640,292,23,Color.WHITE,true)
    for i in range(actions.size()):
        var a := str(actions[i])
        var label: String = str({"resume":"ПРОДОЛЖИТЬ", "next":"СЛЕДУЮЩИЙ УРОВЕНЬ", "restart":"ЗАНОВО", "menu":"В МЕНЮ"}.get(a,a))
        _button(a,str(label),Rect2(402,326+i*84,475,65),i==0)

func _clock(v_seconds: float) -> String:
    var seconds := int(v_seconds)
    return "%02d:%02d" % [seconds/60, seconds%60]
