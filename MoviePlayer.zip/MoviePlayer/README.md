# NeonFilm — offline Android video player

A native Android movie player backed by **VideoLAN LibVLC**. UI in Russian.

## Features
- Local media from Android's system file picker (no storage permission required).
- Common containers/codecs handled by LibVLC: MP4, MKV, AVI, MOV, WebM, FLV, WMV, TS, 3GP, etc. Some proprietary, DRM-protected or corrupted files may not work.
- Double-tap right half of video to seek forwards; double-tap left half to seek backwards. Change gesture step **10 sec / 20 sec** in playback controls.
- Playback controls: ±10 sec, ±20 sec, pause/play, progress bar.
- Embedded subtitles on/off; attach an external SRT/ASS/VTT file, subtitle toggle.
- Automatic rotation with orientation lock toggle; portrait + landscape.
- Recently opened video list and stored playback position.
- Designed for Android 6.0+ (API 23).

## Build locally
Use Java 17, Android SDK 35, Gradle 8.11.1. Run `gradle :app:assembleDebug` from this folder. APK at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
Workflow `.github/workflows/movie-player-apk.yml` lives at the **repository root** and builds `MoviePlayer/` on pushes to branch `movie-player`. The installable APK is found on the build run's **Artifacts → NeonFilm-APK** entry. GitHub packages that artifact as a ZIP; extract to get the APK.

## Notes
No streaming-service catalogs or unofficial movie sources are included. Video opening relies on the document picker and supported media rights. LibVLC is an LGPL component; before distributing commercially, review its licensing terms and those of your app.
