package ru.neonfilm.player;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.interfaces.IMedia;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int PICK_VIDEO = 100;
    private static final int PICK_SUBTITLE = 101;
    private static final int BG = Color.rgb(9, 14, 26);
    private static final int PANEL = Color.rgb(18, 27, 45);
    private static final int SOFT = Color.rgb(35, 49, 75);
    private static final int BLUE = Color.rgb(55, 110, 248);
    private static final int WHITE = Color.rgb(245, 247, 252);
    private static final int MUTED = Color.rgb(163, 177, 200);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private LibVLC libVLC;
    private MediaPlayer player;
    private VLCVideoLayout videoView;
    private Uri currentUri;
    private String currentName = "Фильм не выбран";
    private long resumeAtMs;
    private boolean seekingWithFinger;
    private boolean controlsVisible = true;
    private boolean subtitleDisabled;
    private boolean rotationLocked;
    private int subtitleTrackToRestore = -1;
    private int gestureSeconds = 10;
    private int lastSavedSec = -1;
    private float savedRate = 1f;

    private LinearLayout topBar, bottomBar, libraryArea, root;
    private TextView heading, subheading, playButton, subtitleButton, rotateButton, gestureButton;
    private TextView timeLabel, hintLabel, emptyLabel, speedButton;
    private SeekBar timeline;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null) {
                try {
                    long position = Math.max(0, player.getTime());
                    long length = Math.max(0, player.getLength());
                    timeLabel.setText(clock(position) + " / " + clock(length));
                    if (!seekingWithFinger && length > 0) {
                        timeline.setProgress((int) Math.min(1000, position * 1000 / length));
                    }
                    playButton.setText(player.isPlaying() ? "Ⅱ" : "▶");
                    if (player.isPlaying() && position > 0) {
                        int second = (int)(position / 1000);
                        if (second != lastSavedSec && second % 4 == 0) {
                            savePlaybackPosition(position);
                            lastSavedSec = second;
                        }
                    }
                } catch (Exception ignored) { /* Player may have been released. */ }
            }
            handler.postDelayed(this, 500);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        prefs = getSharedPreferences("neonfilm", MODE_PRIVATE);
        gestureSeconds = prefs.getInt("gesture_seconds", 10);
        subtitleDisabled = prefs.getBoolean("subtitle_disabled", false);
        libVLC = new LibVLC(this, new ArrayList<>());
        player = new MediaPlayer(libVLC);
        player.setEventListener(event -> {
            if (event.type == MediaPlayer.Event.Playing) {
                runOnUiThread(() -> {
                    emptyLabel.setVisibility(View.GONE);
                    if (resumeAtMs > 0) {
                        final long saved = resumeAtMs;
                        resumeAtMs = 0;
                        handler.postDelayed(() -> {
                            if (player != null && player.isSeekable()) player.setTime(saved);
                        }, 300);
                    }
                    if (subtitleDisabled) player.setSpuTrack(-1);
                    playButton.setText("Ⅱ");
                });
            } else if (event.type == MediaPlayer.Event.EncounteredError) {
                runOnUiThread(() -> notifyUser("Не удалось открыть видео. Попробуйте другой файл."));
            } else if (event.type == MediaPlayer.Event.EndReached) {
                runOnUiThread(() -> playButton.setText("▶"));
            }
        });
        buildUi();
        player.attachViews(videoView, null, true, false);
        handler.post(ticker);
        if (getIntent() != null && getIntent().getData() != null) {
            loadVideo(getIntent().getData(), getName(getIntent().getData()), false);
        } else {
            String last = prefs.getString("last_video_uri", "");
            if (!last.isEmpty()) {
                try {
                    loadVideo(Uri.parse(last), prefs.getString("last_video_name", "Последний фильм"), true);
                } catch (Exception ignored) { /* Selected file could have been removed. */ }
            }
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(16), dp(12), dp(12), dp(12));
        root.addView(topBar, new LinearLayout.LayoutParams(-1, dp(68)));

        LinearLayout titleGroup = new LinearLayout(this);
        titleGroup.setOrientation(LinearLayout.VERTICAL);
        topBar.addView(titleGroup, new LinearLayout.LayoutParams(0, -2, 1));
        heading = text("NEONFILM", 21, WHITE, true);
        heading.setLetterSpacing(.09f);
        titleGroup.addView(heading);
        subheading = text("Простой видеоплеер", 12, MUTED, false);
        subheading.setSingleLine(true);
        subheading.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleGroup.addView(subheading);
        topBar.addView(button("＋ Открыть", BLUE, () -> pickFile(PICK_VIDEO)));

        FrameLayout videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        root.addView(videoFrame, new LinearLayout.LayoutParams(-1, 0, 1));
        videoView = new VLCVideoLayout(this);
        videoFrame.addView(videoView, new FrameLayout.LayoutParams(-1, -1));

        emptyLabel = text("▶\n\nОткройте фильм\nиз памяти телефона", 20, MUTED, true);
        emptyLabel.setGravity(Gravity.CENTER);
        videoFrame.addView(emptyLabel, new FrameLayout.LayoutParams(-1, -1));

        hintLabel = text("", 20, WHITE, true);
        hintLabel.setVisibility(View.GONE);
        hintLabel.setGravity(Gravity.CENTER);
        hintLabel.setPadding(dp(16), dp(12), dp(16), dp(12));
        hintLabel.setBackground(round(SOFT, 16));
        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        videoFrame.addView(hintLabel, hintParams);

        View touchOverlay = new View(this);
        videoFrame.addView(touchOverlay, new FrameLayout.LayoutParams(-1, -1));
        GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                setControlsVisible(!controlsVisible);
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                int direction = e.getX() >= videoFrame.getWidth() / 2f ? 1 : -1;
                seekBy(direction * gestureSeconds);
                return true;
            }
        });
        touchOverlay.setOnTouchListener((v, event) -> detector.onTouchEvent(event));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setPadding(dp(10), dp(6), dp(10), dp(8));
        bottomBar.setBackgroundColor(PANEL);
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));

        timeline = new SeekBar(this);
        timeline.setMax(1000);
        timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(BLUE));
        timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(BLUE));
        bottomBar.addView(timeline, new LinearLayout.LayoutParams(-1, dp(35)));
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { seekingWithFinger = true; }
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser && player != null) {
                    long total = Math.max(0, player.getLength());
                    timeLabel.setText(clock(total * value / 1000) + " / " + clock(total));
                }
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                seekingWithFinger = false;
                if (player != null && player.isSeekable()) {
                    long total = Math.max(0, player.getLength());
                    player.setTime(total * bar.getProgress() / 1000);
                }
            }
        });
        timeLabel = text("00:00 / 00:00", 12, MUTED, false);
        timeLabel.setGravity(Gravity.CENTER);
        bottomBar.addView(timeLabel, new LinearLayout.LayoutParams(-1, dp(22)));

        LinearLayout seekButtons = horizontalRow();
        bottomBar.addView(seekButtons, rowLayout());
        addWeighted(seekButtons, button("−20", SOFT, () -> seekBy(-20)));
        addWeighted(seekButtons, button("−10", SOFT, () -> seekBy(-10)));
        playButton = button("▶", BLUE, this::togglePlay);
        addWeighted(seekButtons, playButton);
        addWeighted(seekButtons, button("+10", SOFT, () -> seekBy(10)));
        addWeighted(seekButtons, button("+20", SOFT, () -> seekBy(20)));

        LinearLayout utilityButtons = horizontalRow();
        bottomBar.addView(utilityButtons, rowLayout());
        subtitleButton = button(subtitleDisabled ? "CC: выкл" : "CC: вкл", SOFT, this::toggleSubtitles);
        addWeighted(utilityButtons, subtitleButton);
        addWeighted(utilityButtons, button("＋ SRT", SOFT, () -> pickFile(PICK_SUBTITLE)));
        gestureButton = button("Жест: " + gestureSeconds + "с", SOFT, this::toggleGestureStep);
        addWeighted(utilityButtons, gestureButton);
        rotateButton = button("↻ Авто", SOFT, this::toggleRotation);
        addWeighted(utilityButtons, rotateButton);

        LinearLayout smallRow = horizontalRow();
        bottomBar.addView(smallRow, rowLayout());
        speedButton = button("Скорость: 1×", SOFT, this::changeSpeed);
        addWeighted(smallRow, speedButton);
        addWeighted(smallRow, button("Выбрать другой фильм", SOFT, () -> pickFile(PICK_VIDEO)));

        libraryArea = new LinearLayout(this);
        libraryArea.setOrientation(LinearLayout.VERTICAL);
        libraryArea.setPadding(dp(16), dp(10), dp(16), dp(8));
        root.addView(libraryArea, new LinearLayout.LayoutParams(-1, -2));
        refreshHistory();
        updateOrientationLayout();
    }

    private LinearLayout horizontalRow() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }
    private LinearLayout.LayoutParams rowLayout() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(45));
        params.topMargin = dp(3);
        return params;
    }
    private void addWeighted(LinearLayout row, View view) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(42), 1f);
        params.setMargins(dp(3), 0, dp(3), 0);
        row.addView(view, params);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    private TextView button(String label, int color, Runnable action) {
        TextView view = text(label, 12, WHITE, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(5), dp(4), dp(5), dp(4));
        view.setBackground(round(color, 12));
        view.setOnClickListener(v -> action.run());
        return view;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable result = new GradientDrawable();
        result.setColor(color);
        result.setCornerRadius(dp(radius));
        return result;
    }
    private int dp(float value) { return (int)(getResources().getDisplayMetrics().density * value + 0.5f); }

    private void setControlsVisible(boolean visible) {
        controlsVisible = visible;
        topBar.setVisibility(visible ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(visible ? View.VISIBLE : View.GONE);
        // In portrait, the recent list remains visible only with controls.
        libraryArea.setVisibility(visible && getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE
                ? View.VISIBLE : View.GONE);
    }
    private void updateOrientationLayout() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        libraryArea.setVisibility(!landscape && controlsVisible ? View.VISIBLE : View.GONE);
        topBar.setVisibility(controlsVisible ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(controlsVisible ? View.VISIBLE : View.GONE);
    }

    private void pickFile(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        // All files allows AVI/MKV/ASS files which some document providers do not label correctly.
        intent.setType("*/*");
        try { startActivityForResult(intent, requestCode); }
        catch (ActivityNotFoundException e) { notifyUser("Не найдено приложение для выбора файла"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_VIDEO) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) { /* Temporary access may still work. */ }
            loadVideo(uri, getName(uri), false);
        } else if (requestCode == PICK_SUBTITLE) {
            loadSubtitle(uri);
        }
    }

    private void loadVideo(Uri uri, String name, boolean resume) {
        if (player == null) return;
        try {
            if (currentUri != null) savePlaybackPosition(player.getTime());
            currentUri = uri;
            currentName = name;
            resumeAtMs = resume ? prefs.getLong("resume_" + uri.toString().hashCode(), 0L) : 0L;
            if (!resume) prefs.edit().putLong("resume_" + uri.toString().hashCode(), 0).apply();
            subtitleTrackToRestore = -1;
            Media media = new Media(libVLC, uri);
            media.setHWDecoderEnabled(true, false);
            media.addOption(":file-caching=350");
            player.stop();
            player.setMedia(media);
            media.release();
            player.play();
            player.setRate(savedRate);
            emptyLabel.setVisibility(View.GONE);
            subheading.setText(name);
            setControlsVisible(true);
            saveRecent(uri, name);
            prefs.edit().putString("last_video_uri", uri.toString())
                    .putString("last_video_name", name).apply();
        } catch (Exception error) {
            notifyUser("Не удалось прочитать файл: " + error.getMessage());
            emptyLabel.setVisibility(View.VISIBLE);
        }
    }

    private void togglePlay() {
        if (player == null || currentUri == null) { pickFile(PICK_VIDEO); return; }
        if (player.isPlaying()) player.pause(); else player.play();
    }
    private void seekBy(int seconds) {
        if (player == null || currentUri == null) { notifyUser("Сначала откройте фильм"); return; }
        if (!player.isSeekable()) { notifyUser("Этот файл нельзя перемотать"); return; }
        long duration = player.getLength();
        long target = Math.max(0, player.getTime() + seconds * 1000L);
        if (duration > 0) target = Math.min(duration - 1, target);
        player.setTime(target);
        showHint((seconds > 0 ? "+" : "") + seconds + " сек");
    }
    private void toggleGestureStep() {
        gestureSeconds = gestureSeconds == 10 ? 20 : 10;
        prefs.edit().putInt("gesture_seconds", gestureSeconds).apply();
        gestureButton.setText("Жест: " + gestureSeconds + "с");
        showHint("Двойное касание: " + gestureSeconds + " сек");
    }
    private void toggleSubtitles() {
        if (player == null || currentUri == null) { notifyUser("Сначала откройте фильм"); return; }
        if (!subtitleDisabled) {
            subtitleTrackToRestore = player.getSpuTrack();
            player.setSpuTrack(-1);
            subtitleDisabled = true;
        } else {
            int target = subtitleTrackToRestore;
            if (target < 0) {
                var tracks = player.getSpuTracks();
                if (tracks != null) {
                    for (var track : tracks) {
                        if (track.id >= 0) { target = track.id; break; }
                    }
                }
            }
            if (target < 0 || !player.setSpuTrack(target)) {
                notifyUser("Субтитры не найдены. Выберите файл SRT/ASS/VTT.");
                return;
            }
            subtitleDisabled = false;
        }
        prefs.edit().putBoolean("subtitle_disabled", subtitleDisabled).apply();
        subtitleButton.setText(subtitleDisabled ? "CC: выкл" : "CC: вкл");
        showHint(subtitleDisabled ? "Субтитры выключены" : "Субтитры включены");
    }
    private void loadSubtitle(Uri uri) {
        if (player == null || currentUri == null) { notifyUser("Сначала откройте фильм"); return; }
        try {
            String filename = getName(uri).toLowerCase(Locale.ROOT);
            String extension = ".srt";
            for (String ext : new String[]{".ass", ".ssa", ".vtt", ".sub", ".srt"}) {
                if (filename.endsWith(ext)) { extension = ext; break; }
            }
            File local = new File(getCacheDir(), "selected_subtitle" + extension);
            try (InputStream input = getContentResolver().openInputStream(uri);
                 OutputStream output = new FileOutputStream(local)) {
                if (input == null) throw new IllegalStateException("Файл недоступен");
                byte[] bytes = new byte[16384];
                int count;
                long copied = 0;
                while ((count = input.read(bytes)) != -1) {
                    copied += count;
                    if (copied > 16L * 1024 * 1024) throw new IllegalStateException("Субтитры слишком большие");
                    output.write(bytes, 0, count);
                }
            }
            boolean added = player.addSlave(IMedia.Slave.Type.Subtitle, local.getAbsolutePath(), true);
            if (!added) { notifyUser("Не удалось подключить эти субтитры"); return; }
            subtitleDisabled = false;
            prefs.edit().putBoolean("subtitle_disabled", false).apply();
            subtitleButton.setText("CC: вкл");
            showHint("Субтитры подключены");
        } catch (Exception e) {
            notifyUser("Ошибка субтитров: " + e.getMessage());
        }
    }
    private void toggleRotation() {
        rotationLocked = !rotationLocked;
        if (rotationLocked) {
            int requested = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                    ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
            setRequestedOrientation(requested);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        }
        rotateButton.setText(rotationLocked ? "🔒 Экран" : "↻ Авто");
        showHint(rotationLocked ? "Поворот заблокирован" : "Автоповорот включён");
    }
    private void changeSpeed() {
        if (player == null || currentUri == null) return;
        if (savedRate < 1.25f) savedRate = 1.25f;
        else if (savedRate < 1.5f) savedRate = 1.5f;
        else if (savedRate < 2f) savedRate = 2f;
        else savedRate = 1f;
        player.setRate(savedRate);
        speedButton.setText(String.format(Locale.US, "Скорость: %.2g×", savedRate));
    }
    private void showHint(String value) {
        hintLabel.setText(value);
        hintLabel.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideHint);
        handler.postDelayed(hideHint, 1000);
    }
    private final Runnable hideHint = () -> { if (hintLabel != null) hintLabel.setVisibility(View.GONE); };
    private void notifyUser(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }

    private String getName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment();
        return last == null ? "Видео" : last;
    }
    private void savePlaybackPosition(long position) {
        if (currentUri != null && position > 0) {
            prefs.edit().putLong("resume_" + currentUri.toString().hashCode(), position).apply();
        }
    }
    private void saveRecent(Uri uri, String name) {
        try {
            JSONArray current = new JSONArray(prefs.getString("recents", "[]"));
            JSONArray updated = new JSONArray();
            updated.put(new JSONObject().put("uri", uri.toString()).put("name", name));
            for (int i = 0; i < current.length() && updated.length() < 6; i++) {
                JSONObject item = current.getJSONObject(i);
                if (!uri.toString().equals(item.optString("uri"))) updated.put(item);
            }
            prefs.edit().putString("recents", updated.toString()).apply();
            refreshHistory();
        } catch (Exception ignored) { /* Invalid old recents: non-fatal. */ }
    }
    private void refreshHistory() {
        if (libraryArea == null) return;
        libraryArea.removeAllViews();
        TextView label = text("НЕДАВНО ОТКРЫТЫЕ", 12, MUTED, true);
        label.setLetterSpacing(.08f);
        libraryArea.addView(label);
        try {
            JSONArray recents = new JSONArray(prefs.getString("recents", "[]"));
            if (recents.length() == 0) {
                TextView info = text("Выберите видео через кнопку «Открыть»", 13, MUTED, false);
                info.setPadding(0, dp(12), 0, dp(12));
                libraryArea.addView(info);
                return;
            }
            int number = Math.min(3, recents.length());
            for (int i = 0; i < number; i++) {
                JSONObject item = recents.getJSONObject(i);
                Uri itemUri = Uri.parse(item.optString("uri"));
                String name = item.optString("name", "Фильм");
                TextView entry = text("▶  " + name, 14, WHITE, false);
                entry.setSingleLine(true);
                entry.setEllipsize(android.text.TextUtils.TruncateAt.END);
                entry.setPadding(dp(14), dp(12), dp(14), dp(12));
                entry.setBackground(round(PANEL, 10));
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(43));
                params.topMargin = dp(6);
                libraryArea.addView(entry, params);
                entry.setOnClickListener(v -> loadVideo(itemUri, name, true));
            }
        } catch (Exception ignored) { }
    }
    private String clock(long millis) {
        long seconds = Math.max(0, millis / 1000);
        if (seconds >= 3600) return String.format(Locale.US, "%d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60);
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60);
    }
    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        updateOrientationLayout();
    }
    @Override protected void onStop() {
        if (player != null && currentUri != null) {
            savePlaybackPosition(player.getTime());
            if (player.isPlaying()) player.pause();
        }
        super.onStop();
    }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.setEventListener(null);
            player.stop();
            player.detachViews();
            player.release();
            player = null;
        }
        if (libVLC != null) { libVLC.release(); libVLC = null; }
        super.onDestroy();
    }
}
